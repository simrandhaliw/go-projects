 To add your organization to this list, open a pull request that adds your
 organization's name, optionally with a link. The list is in alphabetical order.

 (Remember to use `git commit --signoff` to comply with the DCO)

# Organizations Using Helm

- [Blood Orange](https://bloodorange.io)
- [IBM](https://www.ibm.com)
- [Microsoft](https://microsoft.com)
- [Qovery](https://www.qovery.com/)
- [Samsung SDS](https://www.samsungsds.com/)
- [Softonic](https://hello.softonic.com/)
- [Ville de Montreal](https://montreal.ca)

_This file is part of the CNCF official documentation for projects._
