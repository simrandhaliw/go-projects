# GCE Cluster addons

These cluster add-ons are specific to GCE and GKE clusters. The GCE-specific addon directory is
merged with the general cluster addon directory at release, so addon paths (relative to the addon
directory) must be unique across the 2 directory structures.

More details on addons in general can be found [here](../../addons/README.md).
