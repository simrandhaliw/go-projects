// Copyright 2019 The Kubernetes Authors.
// SPDX-License-Identifier: Apache-2.0

// Package main contains an example using the the framework.
//
// To generate the Dockerfile for the function image run:
//
//   $ go run ./main.go .
package main
