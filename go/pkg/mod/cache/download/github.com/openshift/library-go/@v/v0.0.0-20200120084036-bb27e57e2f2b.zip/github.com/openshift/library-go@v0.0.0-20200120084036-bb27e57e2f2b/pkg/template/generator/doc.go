// Package generator defines GeneratorInterface interface and implements
// some random value generators.
package generator
