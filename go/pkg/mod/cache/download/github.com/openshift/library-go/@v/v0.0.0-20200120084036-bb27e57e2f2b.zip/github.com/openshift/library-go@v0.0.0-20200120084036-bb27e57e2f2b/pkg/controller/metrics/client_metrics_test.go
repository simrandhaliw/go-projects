package metrics

import (
	"testing"
)

func TestNothing(t *testing.T) {
	t.Log("success!")
}
