// +k8s:deepcopy-gen=package,register
// +k8s:defaulter-gen=TypeMeta
// +k8s:openapi-gen=true

// +groupName=samples.operator.openshift.io
// Package v1 ist he v1 version of the API.
package v1
