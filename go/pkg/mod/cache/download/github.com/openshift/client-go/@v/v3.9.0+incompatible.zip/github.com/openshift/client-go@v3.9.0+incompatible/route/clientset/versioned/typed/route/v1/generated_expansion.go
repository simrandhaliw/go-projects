package v1

type RouteExpansion interface{}
