// This package has the automatically generated fake clientset.
package fake
