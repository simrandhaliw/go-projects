package v1

type OAuthAccessTokenExpansion interface{}

type OAuthAuthorizeTokenExpansion interface{}

type OAuthClientExpansion interface{}

type OAuthClientAuthorizationExpansion interface{}
