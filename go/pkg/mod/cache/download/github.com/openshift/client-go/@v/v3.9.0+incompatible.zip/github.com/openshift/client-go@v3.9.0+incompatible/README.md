OpenShift Client in Go
==============================


Go clients for speaking to an OpenShift cluster.

Versions track OpenShift releases.

See [INSTALL.md](/INSTALL.md) for detailed installation instructions.


## Table of Contents

- [How to use it](#how-to-use-it)


### How to use it

See [examples](/examples).