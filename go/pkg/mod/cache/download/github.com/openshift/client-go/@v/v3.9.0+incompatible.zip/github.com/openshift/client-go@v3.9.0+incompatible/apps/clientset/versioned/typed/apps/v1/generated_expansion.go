package v1

type DeploymentConfigExpansion interface{}
