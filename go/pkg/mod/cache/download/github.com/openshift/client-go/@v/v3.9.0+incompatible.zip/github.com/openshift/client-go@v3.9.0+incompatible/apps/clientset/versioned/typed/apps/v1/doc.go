// This package has the automatically generated typed clients.
package v1
