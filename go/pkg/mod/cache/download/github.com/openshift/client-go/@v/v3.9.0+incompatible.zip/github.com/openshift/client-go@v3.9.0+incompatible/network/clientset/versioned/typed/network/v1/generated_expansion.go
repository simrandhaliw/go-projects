package v1

type ClusterNetworkExpansion interface{}

type EgressNetworkPolicyExpansion interface{}

type HostSubnetExpansion interface{}

type NetNamespaceExpansion interface{}
