// Package fake has the automatically generated clients.
package fake
