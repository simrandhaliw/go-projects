// This package has the automatically generated clientset.
package versioned
