// This package contains the scheme of the automatically generated clientset.
package scheme
