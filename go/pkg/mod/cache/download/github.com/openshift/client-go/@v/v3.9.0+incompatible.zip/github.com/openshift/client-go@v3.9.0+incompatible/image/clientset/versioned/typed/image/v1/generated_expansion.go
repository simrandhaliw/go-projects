package v1

type ImageExpansion interface{}

type ImageSignatureExpansion interface{}

type ImageStreamExpansion interface{}

type ImageStreamImageExpansion interface{}

type ImageStreamImportExpansion interface{}

type ImageStreamMappingExpansion interface{}

type ImageStreamTagExpansion interface{}
