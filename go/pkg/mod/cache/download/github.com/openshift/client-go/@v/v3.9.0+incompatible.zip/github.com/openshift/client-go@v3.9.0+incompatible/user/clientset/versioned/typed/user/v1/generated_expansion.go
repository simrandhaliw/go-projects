package v1

type GroupExpansion interface{}

type IdentityExpansion interface{}

type UserExpansion interface{}

type UserIdentityMappingExpansion interface{}
