package v1

type AppliedClusterResourceQuotaExpansion interface{}

type ClusterResourceQuotaExpansion interface{}
