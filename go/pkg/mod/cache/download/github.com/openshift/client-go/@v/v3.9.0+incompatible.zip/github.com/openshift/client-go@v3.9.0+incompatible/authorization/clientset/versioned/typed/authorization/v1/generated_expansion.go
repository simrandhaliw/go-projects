package v1

type ClusterPolicyExpansion interface{}

type ClusterPolicyBindingExpansion interface{}

type ClusterRoleExpansion interface{}

type ClusterRoleBindingExpansion interface{}

type LocalResourceAccessReviewExpansion interface{}

type LocalSubjectAccessReviewExpansion interface{}

type PolicyExpansion interface{}

type PolicyBindingExpansion interface{}

type ResourceAccessReviewExpansion interface{}

type RoleExpansion interface{}

type RoleBindingExpansion interface{}

type RoleBindingRestrictionExpansion interface{}

type SelfSubjectRulesReviewExpansion interface{}

type SubjectAccessReviewExpansion interface{}

type SubjectRulesReviewExpansion interface{}
