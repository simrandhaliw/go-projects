## 1.2.0 (2017-08-08)

### Bug fixes

* Fix bug where the program would relaunch without the panic wrapper
  [emersion](https://github.com/emersion)
  [#3](https://github.com/bugsnag/panicwrap/pull/3)

* Fix Solaris build
  [Brian Meyers](https://github.com/bmeyers22)
  [#4](https://github.com/bugsnag/panicwrap/pull/4)

## 1.1.0 (2016-01-18)

* Add ARM64 support
  [liusdu](https://github.com/liusdu)
  [#1](https://github.com/bugsnag/panicwrap/pull/1)

## 1.0.0 (2014-11-10)

### Enhancements

* Add ability to monitor a process
