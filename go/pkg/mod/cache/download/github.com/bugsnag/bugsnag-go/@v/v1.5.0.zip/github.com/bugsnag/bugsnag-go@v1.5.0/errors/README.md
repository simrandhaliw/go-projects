Adds stacktraces to errors in golang.

This was made to help build the Bugsnag notifier but can be used standalone if
you like to have stacktraces on errors.

See [Godoc](https://godoc.org/github.com/bugsnag/bugsnag-go/errors) for the API docs.
