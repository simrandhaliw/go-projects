// Package circular exists to break circular dependencies between lexers.
package circular
