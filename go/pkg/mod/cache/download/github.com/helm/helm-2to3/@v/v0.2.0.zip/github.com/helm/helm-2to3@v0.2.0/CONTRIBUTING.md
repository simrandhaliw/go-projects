# Contributing Guidelines

The Helm 2to3 plugin project accepts contributions via GitHub pull requests. 
