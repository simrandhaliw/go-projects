#ifndef USE_LIBSASS_SRC
#include "../../libsass_src/src/utf8_string.cpp"
#endif
