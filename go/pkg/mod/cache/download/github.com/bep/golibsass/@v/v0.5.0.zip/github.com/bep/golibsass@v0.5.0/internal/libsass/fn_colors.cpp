#ifndef USE_LIBSASS_SRC
#include "../../libsass_src/src/fn_colors.cpp"
#endif
