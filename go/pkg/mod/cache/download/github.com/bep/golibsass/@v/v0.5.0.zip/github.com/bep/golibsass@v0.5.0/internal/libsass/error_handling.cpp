#ifndef USE_LIBSASS_SRC
#include "../../libsass_src/src/error_handling.cpp"
#endif
