package test_package

type TestStruct struct {
	TestField string
}
