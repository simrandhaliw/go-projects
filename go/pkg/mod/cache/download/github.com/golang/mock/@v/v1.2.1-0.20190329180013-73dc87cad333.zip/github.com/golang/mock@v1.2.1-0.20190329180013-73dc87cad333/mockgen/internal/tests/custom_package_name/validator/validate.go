package validator

func Validate(s string) error {
	return nil
}
