From #52, this tests an unexported method in the mocked interface.
