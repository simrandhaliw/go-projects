---
name: Feature Request
about: Suggest a feature
title: ''
labels: ''
assignees: ''

---

## Feature Request

**Is your feature request related to a problem? Please describe.**
A clear and concise description of what the problem is. Example: "I have an issue when (...)"

**Describe the solution you'd like**
A clear and concise description of what you want to happen. Add any considered drawbacks.
