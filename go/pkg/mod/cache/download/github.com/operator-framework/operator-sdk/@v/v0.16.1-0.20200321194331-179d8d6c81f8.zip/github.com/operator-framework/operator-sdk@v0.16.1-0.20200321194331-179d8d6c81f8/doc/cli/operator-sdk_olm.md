## operator-sdk olm

Manage the Operator Lifecycle Manager installation in your cluster

### Synopsis

Manage the Operator Lifecycle Manager installation in your cluster

### Options

```
  -h, --help   help for olm
```

### SEE ALSO

* [operator-sdk](operator-sdk.md)	 - An SDK for building operators with ease
* [operator-sdk olm install](operator-sdk_olm_install.md)	 - Install Operator Lifecycle Manager in your cluster
* [operator-sdk olm status](operator-sdk_olm_status.md)	 - Get the status of the Operator Lifecycle Manager installation in your cluster
* [operator-sdk olm uninstall](operator-sdk_olm_uninstall.md)	 - Uninstall Operator Lifecycle Manager from your cluster

