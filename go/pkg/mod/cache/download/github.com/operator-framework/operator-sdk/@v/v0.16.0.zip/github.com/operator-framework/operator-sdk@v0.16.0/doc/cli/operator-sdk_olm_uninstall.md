## operator-sdk olm uninstall

Uninstall Operator Lifecycle Manager from your cluster

### Synopsis

Uninstall Operator Lifecycle Manager from your cluster

```
operator-sdk olm uninstall [flags]
```

### Options

```
  -h, --help               help for uninstall
      --timeout duration   time to wait for the command to complete before failing (default 2m0s)
```

### SEE ALSO

* [operator-sdk olm](operator-sdk_olm.md)	 - Manage the Operator Lifecycle Manager installation in your cluster

