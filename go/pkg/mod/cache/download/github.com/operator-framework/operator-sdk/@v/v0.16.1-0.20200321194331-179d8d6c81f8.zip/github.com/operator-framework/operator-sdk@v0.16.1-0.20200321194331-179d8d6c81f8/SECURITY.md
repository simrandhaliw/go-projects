# Security Policy

## Supported Versions

Operator SDK makes a constant stream of releases. In general, this means that security
updates will be made in minor releases for the most recent major release only.

## Reporting a Vulnerability

To report a vulnerability, please follow the instructions at
https://access.redhat.com/security/team/contact
