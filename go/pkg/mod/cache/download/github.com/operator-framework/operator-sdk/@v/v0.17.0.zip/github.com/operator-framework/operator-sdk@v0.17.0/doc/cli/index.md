CLI documentation is now located in `website/content/en/docs/cli/`
