package ownerutil

import "testing"

func TestIsOwnedBy(t *testing.T) {
	return
}
