// +k8s:deepcopy-gen=package
// +groupName=operators.coreos.com
package v1alpha1
