// +k8s:deepcopy-gen=package

// Package api is the internal version of the API.
// +groupName=operators.coreos.com
package operators
