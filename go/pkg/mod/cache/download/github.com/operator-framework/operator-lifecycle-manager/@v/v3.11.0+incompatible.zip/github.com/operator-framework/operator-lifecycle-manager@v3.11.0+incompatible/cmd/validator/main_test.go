package main

import "testing"

func TestValidatorMain(t *testing.T) {
	main()
}
