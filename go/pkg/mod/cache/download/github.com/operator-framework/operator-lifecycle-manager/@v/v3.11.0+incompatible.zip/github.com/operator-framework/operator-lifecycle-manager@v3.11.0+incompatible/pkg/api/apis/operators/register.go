package operators

const GroupName = "operators.coreos.com"
