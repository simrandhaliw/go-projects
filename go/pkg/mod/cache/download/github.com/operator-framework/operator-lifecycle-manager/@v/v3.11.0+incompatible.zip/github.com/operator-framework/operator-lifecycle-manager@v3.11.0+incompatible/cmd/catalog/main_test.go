package main

import (
	"testing"
)

// Test started when the test binary is started. Only calls main.
func TestCatalogMain(t *testing.T) {
	main()
}
