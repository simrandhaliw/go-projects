// Package version supplies the type for version information collected at build time.
package version
