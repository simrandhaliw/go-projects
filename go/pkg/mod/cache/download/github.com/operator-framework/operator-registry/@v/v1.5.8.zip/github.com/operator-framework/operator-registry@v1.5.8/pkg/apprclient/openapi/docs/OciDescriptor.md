# OciDescriptor

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Digest** | **string** | content digest | [optional] 
**Size** | **int64** | blob size | [optional] 
**MediaType** | **string** | content type | [optional] 
**Urls** | **[]string** | download mirrors | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


