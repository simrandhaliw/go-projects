# PackageDescription

## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Default** | **string** | default | [optional] 
**Visibility** | **string** | visibility | [optional] 
**Manifests** | **[]string** |  | [optional] 
**Channels** | **[]string** |  | [optional] 
**CreatedAt** | **string** | Package creation date | [optional] 
**UpdatedAt** | **string** | Package creation date | [optional] 
**Name** | **string** | Package name | [optional] 
**Namespace** | **string** | namespace | [optional] 
**Releases** | **[]string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


