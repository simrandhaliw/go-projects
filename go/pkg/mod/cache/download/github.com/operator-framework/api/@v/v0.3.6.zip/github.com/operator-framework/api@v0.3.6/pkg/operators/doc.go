// +k8s:deepcopy-gen=package
// +groupName=operators.coreos.com
// +kubebuilder:skip
// Package operators contains all resource types of the operators.coreos.com API group.
package operators
