// Package crds contains CustomResourceDefinition manifests for operator-framework APIs.
package crds
