## Performance Utility

Downloads an Object from an S3 bucket in a loop for a set number of iterations
or time limit. The utility outputs the connection and SDK timing metrics in CSV
format.

