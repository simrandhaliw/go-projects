// Copyright 2016 The Gini Authors. All rights reserved.  Use of this source
// code is governed by a license that can be found in the License file.

// Package dimacs provides support for reading dimacs cnf files and variants.
package dimacs
