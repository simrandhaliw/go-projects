// Copyright 2016 The Gini Authors. All rights reserved.  Use of this source
// code is governed by a license that can be found in the License file.

package crisp

import (
	"github.com/irifrance/gini/inter/net"
	"testing"
)

func TestClient(t *testing.T) {
	var c *Client
	var f = func(n net.S) {

	}
	f(c)
}
